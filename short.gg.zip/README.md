<img src="https://raw.githubusercontent.com/ShortGG/graphic-chart/master/logo.png" alt="logo-short-gg" width="25%" align="right" />

<br />

# chrome extension of short.gg

Automatically shortens current tab

# Preview

<a href="https://short.gg">short.gg</a>

![illustration](./illustrations/preview.gif)
